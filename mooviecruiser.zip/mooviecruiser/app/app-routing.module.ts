import { NgModule, Component } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { MovieItemEditComponent } from "./movie/movie-item-edit/movie-item-edit.component";
import { MovieItemInfoComponent } from "./movie/movie-item-info/movie-item-info.component";
import { MovieListComponent } from "./movie/movie-list/movie-list.component";
import { MovieSearchComponent } from "./movie/movie-search/movie-search.component";
import { BookingFavoritesComponent } from "./booking/booking-favorites/booking-favorites.component";
import { LoginComponent } from "./site/login/login.component";
import { SignupComponent } from "./site/signup/signup.component";
import { AuthServiceGuardGuard } from "./site/auth-service-guard.guard";

const routes: Routes = [
  { path: "movie-item-edit/:id", component: MovieItemEditComponent },
  { path: "movie-item-info", component: MovieItemInfoComponent },
  { path: "movie-list", component: MovieListComponent },
  { path: "movie-search", component: MovieSearchComponent },
  {
    path: "booking-favorites",
    component: BookingFavoritesComponent,
    canActivate: [AuthServiceGuardGuard]
  },
  { path: "login", component: LoginComponent },
  { path: "signup", component: SignupComponent },
  { path: "", component: MovieSearchComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
