import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { MovieItemServiceService } from "./services/movie-item-service.service";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { MovieItemInfoComponent } from "./movie/movie-item-info/movie-item-info.component";
import { MovieListComponent } from "./movie/movie-list/movie-list.component";
import { MovieSearchComponent } from "./movie/movie-search/movie-search.component";
import { BookingFavoritesComponent } from "./booking/booking-favorites/booking-favorites.component";
import { MovieItemEditComponent } from "./movie/movie-item-edit/movie-item-edit.component";
import { ReactiveFormsModule } from "@angular/forms";
import { SignupComponent } from "./site/signup/signup.component";
import { LoginComponent } from "./site/login/login.component";
import { HttpClientModule } from "@angular/common/http";
@NgModule({
  declarations: [
    AppComponent,
    MovieItemInfoComponent,
    MovieListComponent,
    MovieSearchComponent,
    BookingFavoritesComponent,
    MovieItemEditComponent,
    SignupComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [MovieItemServiceService],
  bootstrap: [AppComponent]
})
export class AppModule {}
