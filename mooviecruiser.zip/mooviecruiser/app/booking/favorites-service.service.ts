import { Injectable } from "@angular/core";
import { FavoritesItem } from "./booking-favorites/favorites-item";
import { MovieItem } from "../movie/movie-item";

@Injectable({
  providedIn: "root"
})
export class FavoritesServiceService {
  favorites: FavoritesItem = {
    movieItems: [],
    total: 0
  };

  constructor() {}

  getFavorites() {
    return this.favorites;
  }
  emptyFavorites() {
    this.favorites = { movieItems: [], total: 0 };
  }

  addToFavorites(favoritesItem: MovieItem) {
    this.favorites.movieItems.push(favoritesItem);
    this.totalCalculate(favoritesItem.boxOffice);
    console.log(this.favorites);
  }

  totalCalculate(total: number) {
    this.favorites.total++;
  }

  removeFavorites(id: number) {
    const index = this.favorites.movieItems.findIndex(movie => movie.id == id);
    const itemToRemove = this.favorites.movieItems.splice(index, 1)[0];
    this.favorites.total--;
  }
}
