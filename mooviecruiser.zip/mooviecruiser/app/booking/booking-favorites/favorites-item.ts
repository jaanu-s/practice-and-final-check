import { MovieItem } from "src/app/movie/movie-item";

export interface FavoritesItem {
  movieItems: MovieItem[];
  total: number;
}
