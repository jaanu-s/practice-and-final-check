import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { BookingFavoritesComponent } from "./booking-favorites.component";

describe("BookingFavoritesComponent", () => {
  let component: BookingFavoritesComponent;
  let fixture: ComponentFixture<BookingFavoritesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BookingFavoritesComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingFavoritesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
