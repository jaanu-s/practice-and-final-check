import { Component, OnInit } from "@angular/core";
import { FavoritesServiceService as FavoritesService } from "../favorites-service.service";
import { MovieItem } from "src/app/movie/movie-item";
import { FavoritesItem } from "./favorites-item";
import { Router } from "@angular/router";
import { MovieItemServiceService } from "src/app/services/movie-item-service.service";
import { AuthServiceService } from "src/app/services/authentication-service.service";

@Component({
  selector: "app-booking-favorites",
  templateUrl: "./booking-favorites.component.html",
  styleUrls: ["./booking-favorites.component.css"]
})
export class BookingFavoritesComponent implements OnInit {
  constructor(
    private router: Router,
    public movieService: MovieItemServiceService,
    private service2: AuthServiceService
  ) {}
  displayFavorites: any;
  isCustomer: boolean = this.service2.isAdmin();
  userName: string = this.service2.getUserName();
  isFavoritesEmpty: boolean;
  isRemoved: boolean;
  num: number;

  ngOnInit() {
    this.isRemoved = false;
    this.movieService
      .getFavorites(this.service2.getUserName())
      .subscribe(data => {
        //console.log(data);
        
        this.displayFavorites = data;
        console.log(this.displayFavorites.movieItemList);
        if (data == null || this.displayFavorites.total == 0) this.isFavoritesEmpty = true;
        else this.isFavoritesEmpty = false;
      });
  }
  logOut() {
    this.service2.logOut();
    this.userName = this.service2.getUserName();
    this.router.navigateByUrl("/login");
  }
  removeFavorites(id: number) {
    this.movieService
      .removeFavorites(this.service2.getUserName(), id)
      .subscribe(() =>
        this.movieService
          .getFavorites(this.service2.getUserName())
          .subscribe(data => {
            //console.log(data);
           
            this.displayFavorites = data;
            if (this.displayFavorites.total == 0) {
              this.isFavoritesEmpty = true;
            } else this.isFavoritesEmpty = false;
          })
      );
    this.isRemoved = true;
  }
}
 