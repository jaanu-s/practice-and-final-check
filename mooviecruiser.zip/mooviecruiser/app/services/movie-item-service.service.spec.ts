import { TestBed } from "@angular/core/testing";

import { MovieItemServiceService } from "./movie-item-service.service";

describe("MovieItemServiceService", () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it("should be created", () => {
    const service: MovieItemServiceService = TestBed.get(
      MovieItemServiceService
    );
    expect(service).toBeTruthy();
  });
});
