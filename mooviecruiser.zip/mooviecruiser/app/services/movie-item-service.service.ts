import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { AuthServiceService } from "./authentication-service.service";
import { UserAuthServiceService } from "./user-auth-service.service";
import { Observable } from "rxjs";
import { environment } from "src/environments/environment";
import { MovieItem } from "../movie/movie-item";
import { FavoritesItem } from "../booking/booking-favorites/favorites-item";
import { UserList } from "../site/user-list";

@Injectable({
  providedIn: "root"
})
export class MovieItemServiceService {
  movie: MovieItem[] = [];
  favorites: any;
  ClickOnAdd:boolean=false;

  constructor(
    private http: HttpClient,
    public service: UserAuthServiceService,
    public authService: AuthServiceService
  ) {}

  private baseUrl = environment.baseUrl;

  getAllMovieItems(): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
     return this.http.get(this.baseUrl + "/movie-service/movie-items", httpOptions);
  }

  getMovieItem(id: any) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
     return this.http.get(`${this.baseUrl}/movie-service/movie-items/${id}`, httpOptions);
  }

  addUser(newuser: UserList) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    console.log("Adduser" + newuser);
   return this.http.post(`${this.baseUrl}/authentication-service/users`, newuser, httpOptions);
  } 

  updateMovieItem(editMovie: any) {
    console.log(editMovie);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    return this.http.put(`${this.baseUrl}/movie-service/movie-items`, editMovie, httpOptions);
  }

  addFavoritesItem(id: string, favoritesItem: number) {
    console.log(favoritesItem);

    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    console.log(this.baseUrl + "/favorites/" + id + "/" + favoritesItem);
    return this.http.post<void>(
      this.baseUrl + "/movie-service/favorites/" + id + "/" + favoritesItem,
      favoritesItem,
      httpOptions
    );
  }

  getFavorites(id: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    return this.http.get(`${this.baseUrl}/movie-service/favorites/` + id, httpOptions);
  }

  removeFavorites(userId: string, id: number) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    return this.http.delete<void>(
      this.baseUrl + "/movie-service/favorites/" + userId + "/" + id,
      httpOptions
    );
  }

  getMovieItems1(searchText: string) {
    if (this.authService.isAdmin()) {
      if (searchText == "") {
        this.getAllMovieItems().subscribe(data => (this.movie = data));
        return this.movie;
      } else {
        this.getAllMovieItems().subscribe(data => (this.movie = data));
        let filteredMovie = this.movie.filter(
          x => x.title.toLowerCase().indexOf(searchText.toLowerCase()) !== -1
        );
        return filteredMovie;
      }
    } else {
      if (searchText == "") {
        this.getAllMovieItems().subscribe(data => (this.movie = data));
        return this.movie;
      } else {
        this.getAllMovieItems().subscribe(data => (this.movie = data));
        let filteredMovie = this.movie.filter(
          x => x.title.toLowerCase().indexOf(searchText.toLowerCase()) !== -1
        );
        return filteredMovie;
      }
    }
  }
}
