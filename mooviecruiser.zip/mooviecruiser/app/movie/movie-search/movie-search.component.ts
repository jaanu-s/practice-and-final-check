import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { MovieItem } from "../movie-item";
import { MovieListComponent } from "../movie-list/movie-list.component";
import { MovieItemServiceService } from "src/app/services/movie-item-service.service";
import { AuthServiceService } from "src/app/services/authentication-service.service";

@Component({
  selector: "app-movie-search",
  templateUrl: "./movie-search.component.html",
  styleUrls: ["./movie-search.component.css"]
})
export class MovieSearchComponent implements OnInit {
  searchText: string;
  movie: MovieItem[];
  isLogged: Boolean;
  userName: string = this.service2.getUserName();
  isCustomer: Boolean = this.service2.isAdmin();

  constructor(
    public movieService: MovieItemServiceService,
    private service2: AuthServiceService,
    private router: Router
  ) {}

  ngOnInit() {
    this.isLogged = this.service2.isLogged();
    this.userName = this.service2.getUserName();
  }

  search() {
    this.movie = this.movieService.getMovieItems1(this.searchText);
  }
  logOut() {
    this.service2.logOut();
    this.userName = this.service2.getUserName();
    this.router.navigateByUrl("/login");
  }
}
