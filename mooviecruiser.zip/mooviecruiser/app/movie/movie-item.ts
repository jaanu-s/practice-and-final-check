export interface MovieItem {
  id: number;
  title: string;
  boxOffice: number;
  active: Boolean;
  dateOfLaunch: Date;
  genre: string;
  hasTeaser: Boolean;
  url: string;
}
