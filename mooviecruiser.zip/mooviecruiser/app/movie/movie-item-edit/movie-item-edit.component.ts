import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { FavoritesServiceService } from "src/app/booking/favorites-service.service";
import { ActivatedRoute, Router } from "@angular/router";
import { MovieItem } from "../movie-item";
import { MovieItemServiceService } from "src/app/services/movie-item-service.service";
import { AuthServiceService } from "src/app/services/authentication-service.service";
import {formatDate} from "@angular/common";
@Component({
  selector: "app-movie-item-edit",
  templateUrl: "./movie-item-edit.component.html",
  styleUrls: ["./movie-item-edit.component.css"]
})
export class MovieItemEditComponent implements OnInit {
  constructor(
    private movieService: MovieItemServiceService,
    private service2: AuthServiceService,
    private route: ActivatedRoute,
    private router: Router
  ) {}
  editForm: FormGroup;
  movieId = this.route.snapshot.paramMap.get("id");
  favoriteItems: any;
  editted: Boolean = false;
  userName: string = this.service2.getUserName();
  added: boolean = false;

  ngOnInit() {
    let mid = Number(this.movieId);
    console.log(this.movieId);
    this.movieService.getMovieItem(mid).subscribe(data => {
      console.log(data);
      this.favoriteItems = data;

      this.editForm = new FormGroup({
        title: new FormControl(this.favoriteItems.title, [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(20)
        ]),
        boxOffice: new FormControl(this.favoriteItems.boxOffice, [
          Validators.required,
          Validators.pattern("^[0-9]*$")
        ]),
        active: new FormControl(this.favoriteItems.active, [
          Validators.required
        ]),
        dateOfLaunch: new FormControl(formatDate(this.favoriteItems.dateOfLaunch,'yyyy-MM-dd','en'), [
          Validators.required
        ]),
        genre: new FormControl(this.favoriteItems.genre, [Validators.required]),
        hasTeaser: new FormControl(this.favoriteItems.hasTeaser, []),
        url: new FormControl(this.favoriteItems.url, [Validators.required])
      });

      this.editForm
        .get("title")
        .valueChanges.subscribe(value => (this.favoriteItems.title = value));
      this.editForm
        .get("boxOffice")
        .valueChanges.subscribe(
          value => (this.favoriteItems.boxOffice = value)
        );
      this.editForm
        .get("active")
        .valueChanges.subscribe(value => (this.favoriteItems.active = value));
      this.editForm
        .get("url")
        .valueChanges.subscribe(value => (this.favoriteItems.url = value));
      this.editForm
        .get("genre")
        .valueChanges.subscribe(value => (this.favoriteItems.genre = value));
      this.editForm
        .get("hasTeaser")
        .valueChanges.subscribe(
          value => (this.favoriteItems.hasTeaser = value)
        );
      this.editForm
        .get("dateOfLaunch")
        .valueChanges.subscribe(
          value => (this.favoriteItems.dateOfLaunch = value)
        );
    });
  }

  logOut() {
    this.service2.logOut();
    this.router.navigateByUrl("/login");
  }
  onSubmit() {
    this.movieService.updateMovieItem(this.favoriteItems).subscribe();
    this.editted = true;
  }
  get title() {
    return this.editForm.get("title");
  }
  get boxOffice() {
    return this.editForm.get("boxOffice");
  }
  get active() {
    return this.editForm.get("active");
  }
  get url() {
    return this.editForm.get("url");
  }
  get dateOfLaunch() {
    return this.editForm.get("dateOfLaunch");
  }
  get genre() {
    return this.editForm.get("genre");
  }
  get hasTeaser() {
    return this.editForm.get("hasTeaser");
  }
}
