import { Component, OnInit, Input } from "@angular/core";
import { MovieItem } from "../movie-item";
import { MovieItemServiceService } from "src/app/services/movie-item-service.service";
import { UserAuthServiceService } from "src/app/services/user-auth-service.service";

@Component({
  selector: "app-movie-list",
  templateUrl: "./movie-list.component.html",
  styleUrls: ["./movie-list.component.css"]
})
export class MovieListComponent implements OnInit {
  role: string;

  @Input()
  public movieItems: any;

  constructor(
    public movieItemService: MovieItemServiceService,
    public userService: UserAuthServiceService
  ) {}

  ngOnInit() {
    this.role = this.userService.getRole();
    console.log(this.role);
    this.movieItemService
      .getAllMovieItems()
      .subscribe(data => (this.movieItems = data));
    console.log(this.movieItems);
  }
}
