import { Component, OnInit, Input } from "@angular/core";
import { MovieItem } from "../movie-item";
import { FavoritesServiceService } from "src/app/booking/favorites-service.service";
import { Router } from "@angular/router";
import { MovieItemServiceService } from "src/app/services/movie-item-service.service";
import { AuthServiceService } from "src/app/services/authentication-service.service";

@Component({
  selector: "app-movie-item-info",
  templateUrl: "./movie-item-info.component.html",
  styleUrls: ["./movie-item-info.component.css"]
})
export class MovieItemInfoComponent implements OnInit {
  isAdmin: Boolean = false;
  added: Boolean = false;
  plsLogin: boolean = false;
  ClickOnAdd:boolean=false;
Addedid:number = 0;
  @Input() movie: any;
  constructor(
    public service: MovieItemServiceService,
    public service2: AuthServiceService,
    private router: Router
  ) {}

  ngOnInit() {
    this.isAdmin = this.service2.isAdmin();
    if (this.isAdmin) {
      this.service.getAllMovieItems().subscribe(data => (this.movie = data));
    }
  }
  addToFavorites(item: number) {
    if (this.service2.isLogged()) {
      this.service
        .addFavoritesItem(this.service2.getUserName(), item)
        .subscribe();
      this.added = true;
      this.Addedid = item;
    } else {
      this.service.ClickOnAdd=true;
      this.router.navigateByUrl("/login");
    }
  }
}
