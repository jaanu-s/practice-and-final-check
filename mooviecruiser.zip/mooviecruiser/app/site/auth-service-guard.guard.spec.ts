import { TestBed, async, inject } from "@angular/core/testing";

import { AuthServiceGuardGuard } from "./auth-service-guard.guard";

describe("AuthServiceGuardGuard", () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthServiceGuardGuard]
    });
  });

  it("should ...", inject(
    [AuthServiceGuardGuard],
    (guard: AuthServiceGuardGuard) => {
      expect(guard).toBeTruthy();
    }
  ));
});
