package com.cognizant.authentication.model;

import java.util.List;


public class Favorites {
	private List<MovieList> movieItemList;
	private double total;

	public Favorites() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Favorites(List<MovieList> movieItemList, double total) {
		super();
		this.movieItemList = movieItemList;
		this.total = total;
	}

	public List<MovieList> getMovieItemList() {
		return movieItemList;
	}

	public void setMovieItemList(List<MovieList> list) {
		this.movieItemList = list;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((movieItemList == null) ? 0 : movieItemList.hashCode());
		long temp;
		temp = Double.doubleToLongBits(total);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Favorites other = (Favorites) obj;
		if (movieItemList == null) {
			if (other.movieItemList != null)
				return false;
		} else if (!movieItemList.equals(other.movieItemList))
			return false;
		if (Double.doubleToLongBits(total) != Double.doubleToLongBits(other.total))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Favorites [movieItemList=" + movieItemList + ", total=" + total + "]";
	}

}
