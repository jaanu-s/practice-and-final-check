package com.cognizant.movieservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.movieservice.model.MovieList;


@Repository
public interface MovieListRepository extends JpaRepository<MovieList, Integer> {
	@Query(value = "select * from finalcheck_v2.movie_item where mo_active = '1' && mo_date_of_launch < \"2019-01-01\"", nativeQuery = true)
	List<MovieList> getMovieItem();
	public Optional<MovieList> findById(int movieId);
}
