package com.cognizant.movieservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.movieservice.model.Favorites;
import com.cognizant.movieservice.service.FavoritesService;

@RestController
@RequestMapping("/favorites")
public class FavoritesController {

	@Autowired
	public FavoritesService favoritesService;

	@PostMapping("/{userId}/{movieId}")
	public void addFavoritesItem(@PathVariable String userId, @PathVariable long movieId) {
		favoritesService.addFavoritesItem(userId, movieId);
	}

	@GetMapping("/{userId}")
	public Favorites getAllFavoritesItem(@PathVariable String userId) {
		return favoritesService.getAllFavoritesItem(userId);
	}

	@DeleteMapping("/{userId}/{movieId}")
	public void deleteFavoritesItem(@PathVariable String userId, @PathVariable long movieId) {
		favoritesService.deleteFavoritesItem(userId, movieId);
	}

}
