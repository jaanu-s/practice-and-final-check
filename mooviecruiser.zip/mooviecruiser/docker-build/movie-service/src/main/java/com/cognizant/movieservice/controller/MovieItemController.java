package com.cognizant.movieservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.movieservice.model.MovieList;
import com.cognizant.movieservice.service.AppUserDetailsService;
import com.cognizant.movieservice.service.MovieItemService;

@RestController
@RequestMapping("/movie-items")
public class MovieItemController {

	@Autowired
	private MovieItemService movieItemService;
//	@Autowired
//	private InMemoryUserDetailsManager inMemoryUserDetailsManager;
	@Autowired
	AppUserDetailsService appUserDetailsService;

	@GetMapping()
	public List<MovieList> getAllMovieItems() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String user = authentication.getName();
		System.out.println(user);

		if (user.equals("anonymousUser")) {

			return movieItemService.getMovieItemListCustomer();

		} else {

			UserDetails userDetails = appUserDetailsService.loadUserByUsername(user);
			String role = userDetails.getAuthorities().toArray()[0].toString();

			if (role.equalsIgnoreCase("role_admin"))
				return (ArrayList<MovieList>) movieItemService.getMovieItemListAdmin();
			else

				return movieItemService.getMovieItemListCustomer();

		}

	}

	@GetMapping("/{id}")
	public MovieList getMovieItem(@PathVariable long id) {
		return movieItemService.getMovieItem(id);
	}

	@PutMapping
	public void modifyMovieItem(@RequestBody MovieList movies) {
		movieItemService.modifyMovieItem(movies);
	}

}
