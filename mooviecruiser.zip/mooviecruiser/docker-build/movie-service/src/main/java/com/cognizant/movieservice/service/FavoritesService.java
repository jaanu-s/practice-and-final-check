package com.cognizant.movieservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.movieservice.model.Favorites;
import com.cognizant.movieservice.model.MovieList;
import com.cognizant.movieservice.model.User;
import com.cognizant.movieservice.repository.MovieListRepository;
import com.cognizant.movieservice.repository.UserRepository;

@Service
public class FavoritesService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	MovieListRepository movieListRepository;
//
//	@Autowired
//	public FavoritesDao favoritesDao = new FavoritesDaoCollectionImpl();

	public void addFavoritesItem(String userId, long movieId) {
		// favoritesDao.addFavoritesItem(userId, movieId);

		User user = userRepository.findByUserName(userId);

		MovieList movieList = movieListRepository.findById((int) movieId).get();
		if (movieList != null) {
			List<MovieList> a = new ArrayList<MovieList>();
			a = user.getmovieItemList();
			a.add(movieList);
			user.setmovieItemList(a);
			userRepository.save(user);

		}

	}

	public Favorites getAllFavoritesItem(String userId) {
//		return favoritesDao.getAllFavoritesItem(userId);

		Favorites favorites = new Favorites();

		User user = userRepository.findByUserName(userId);
		// double total = userRepository.getCartTotal(userId);

		favorites.setMovieItemList(user.getmovieItemList());

		try {
			favorites.setTotal(userRepository.getFavoritesTotal(user.getId()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return favorites;

	}

	public void deleteFavoritesItem(String userId, long movieId) {
		// favoritesDao.deleteFavoritesItem(userId, movieId);

		User user = userRepository.findByUserName(userId);

		MovieList movieList = movieListRepository.findById((int) movieId).get();

		List<MovieList> a = user.getmovieItemList();
		a.remove(movieList);
		user.setmovieItemList(a);
		userRepository.save(user);

	}

}
