package com.cognizant.movieservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.movieservice.model.MovieList;
import com.cognizant.movieservice.repository.MovieListRepository;

@Service
public class MovieItemService {
//	@Autowired
//	public MovieItemDaoCollectionImpl movieItemDao;

	@Autowired
	MovieListRepository movieListRepository;

	public List<MovieList> getMovieItemListCustomer() {
//		return movieItemDao.getMovieItemListCustomer();
		return movieListRepository.getMovieItem();
	}

	public List<MovieList> getMovieItemListAdmin() {
//		return movieItemDao.getMovieItemListAdmin();
		return movieListRepository.findAll();
	}

	public MovieList getMovieItem(long movieId) {
//		return movieItemDao.getMovieItem(movieId);
//		
		return movieListRepository.findById((int) movieId).get();
	}

	public void modifyMovieItem(MovieList movieList) {
//		movieItemDao.modifyMovieItem(movies);
//		
		movieListRepository.save(movieList);

	}

}
