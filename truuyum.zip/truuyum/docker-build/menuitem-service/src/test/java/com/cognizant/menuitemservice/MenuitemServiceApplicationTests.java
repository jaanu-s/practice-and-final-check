/*package com.cognizant.menuitemservice;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MenuitemServiceApplicationTests {

	@org.junit.Test
	void contextLoads() {
	}

}*/
