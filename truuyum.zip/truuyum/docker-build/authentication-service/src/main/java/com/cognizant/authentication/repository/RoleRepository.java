package com.cognizant.authentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.authentication.model.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {

	public Role findByRoleId(int id);

}
