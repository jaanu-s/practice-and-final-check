/*package com.cognizant.authentication;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}*/
