import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthServiceService } from '../site/auth-service.service';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class MenuItemService {

  private subject = new Subject<Observable<any>>();
  baseurl:string=environment.baseUrl;
  cartUrl:string=environment.cartSUrl;
  constructor(private _httpClient: HttpClient) { }

  getAllMenuItems(): Observable<any> {

    if (localStorage.getItem('token')) {
      var headers_object = new HttpHeaders();
      headers_object.set('Content-Type', 'application/json');
      var head = headers_object.set("Authorization", "Bearer " + localStorage.getItem('token'));
      alert(JSON.stringify(headers_object) + "header object" + localStorage.getItem('token'));
      //alert("in iffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff")
      return this._httpClient.get<any>(this.baseurl, { headers: head });

      //return this._httpClient.get<any>("http://localhost:8083/menu-items");
    }
    else {
      let username = 'default'
      let password = 'pwd'
      var headers = new HttpHeaders();
      alert("in defffffault")
      headers = headers.set("Authorization", 'Basic ' + btoa(username + ':' + password));
      return this._httpClient.get<any>(this.baseurl, { headers });

    }

  }
  getSubject(): Subject<Observable<any>> {
    return this.subject;
  }

  getMenuItem(id): Observable<any> {
    //alert("in menu service");
    var headers_object = new HttpHeaders();
    headers_object.set('Content-Type', 'application/json');
    var head = headers_object.set("Authorization", "Bearer " + localStorage.getItem('token'));
    alert(JSON.stringify(headers_object) + "header object" + localStorage.getItem('token'));
    //alert("in get serviceeeeeeeeeeeeeeeeee")
    return this._httpClient.get<any>(this.baseurl+ id, { headers: head });
    //return this._httpClient.get<any>("http://localhost:8083/menu-items/"+id);
  }

  save(menuItem): Observable<any> {
    alert("in put method in menu service" + menuItem);
    var headers_object = new HttpHeaders();
    headers_object.set('Content-Type', 'application/json');
    var head = headers_object.set("Authorization", "Bearer " + localStorage.getItem('token'));
    alert(JSON.stringify(headers_object) + "header object" + localStorage.getItem('token'));
    return this._httpClient.put<any>(this.baseurl, menuItem, { headers: head });
    //return this._httpClient.put<any>("http://localhost:8083/menu-items",menuItem);
  }
  addCartItem(userId, menuItemId): Observable<any> {
    var headers_object = new HttpHeaders();
    headers_object.set('Content-Type', 'application/json');
    var head = headers_object.set("Authorization", "Bearer " + localStorage.getItem('token'));
    alert(JSON.stringify(headers_object) + "header object" + localStorage.getItem('token'));
    return this._httpClient.post<any>(this.cartUrl + userId + "/" + menuItemId, null, { headers: head });
    // return this._httpClient.post<any>("http://localhost:8083/carts/"+userId+"/"+menuItemId,null);
  }
}
