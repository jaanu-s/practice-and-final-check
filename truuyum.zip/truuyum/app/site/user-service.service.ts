import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { User } from '../user';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  userName:User;
useradded:boolean;
msg:string=null;
userurl:string=environment.userUrl;

  userList = [
    {username:'admin',firstname:"",lastname:"admin",password:"pwd"},
    {username:'user',firstname:"user",lastname:"",password:"pwd"}
  ];
  
  constructor(private router:Router,private _httpClient:HttpClient) { }

  addNewUser(newUser:User):Observable<any>
{
//  alert("I am in http add method")
//  alert("userrr"+JSON.stringify(newUser))

 // alert("url user"+JSON.stringify(this._httpClient.post("http://localhost:8083/users",newUser)));
  return this._httpClient.post(this.userurl,newUser);
}

  addUser(user:any) {
    this.userList.push(user);
    this.addNewUser(user).subscribe((res)=>{

      this.useradded=res;
      alert("user added value ==>"+this.useradded);
      this.router.navigate(['login']);
  },
  (error : HttpErrorResponse)=>{
    //this.employeeList=error;
    this.msg=error.message;
   // this.router.navigate(['login']);
    alert("error in authenticate"+error.message);
    if(error instanceof Error)
    {
      alert("errrrr cllient"+error.message)
    }else
    {
      alert("server side"+error.message);
    }
  }
  )

    //this.router.navigate(['login']);
  }
  getUser(username:string){
    let user = this.userList.filter((user)=>(user.username==username));
    return user[0];
  }
}