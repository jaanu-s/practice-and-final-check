import { Injectable } from '@angular/core';
import { UserServiceService } from './user-service.service';
import { Router } from '@angular/router';
import { FoodServiceService } from '../food/food-service.service';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  loggedInUser={loggedOut:true};
  validCredentials:boolean = true;
  accessToken: string; // JWT token
  redirectUrl = '/';
  loggedIn:boolean = false;
  name:string;
  username:string;
  role: string="";
  constructor(private userService:UserServiceService,public router: Router,private _httpClient:HttpClient,private foodService:FoodServiceService) { }

  private authenticationApiUrl:string=environment.authbaseUrl;

  token: string="";
  
authenticate(user: string, password: string): Observable<any> {

  var up=user+":"+password;
  var credentials=btoa(user + ':' + password);
  alert("it has come to authenticate");
  alert(credentials+"-----credentialsssssss");
  let headers = new HttpHeaders();
  headers = headers.set('Authorization', 'Basic ' + credentials);
 alert(JSON.stringify(headers)+"----headers");
  return this._httpClient.get(this.authenticationApiUrl, {headers});

}
  authenticateUser(user) {
    // for(let validUser of this.userService.userList){
    //   if(validUser.username == user.username && validUser.password == user.password){
    //     this.loggedInUser = user;
    //     this.validCredentials = true;
    //     if(user.username == 'admin')
    //       this.foodService.isAdmin = true;
    //     this.router.navigate(['search-bar']);
    //     this.loggedIn = true;
    //     this.foodService.isLoggedIn = true;
    //     this.name = this.userService.getUser(user.username).lastname.concat(".").concat(this.userService.getUser(user.username).firstname);
    //     this.username=user.username;
    //   }
    //   else
    //     this.validCredentials = false;
    // }


    // for(let validUser of this.userService.userList){
    //   if(validUser.username == user.username && validUser.password == user.password){
       this.authenticate(user.username,user.password).subscribe((item) => { 
        //  alert("item token"+JSON.stringify(item));
        //  alert(item.role+"============role is ");
          this.setToken(item.token);
          this.setRole(item.role);
          localStorage.setItem('token',item.token);
          localStorage.setItem('role',item.role);
       //  alert( "token from get is-------------"+this.getToken());
         // alert("role from get is-------------"+this.getRole());
          this.loggedInUser = user;
          this.validCredentials = true;
          if(this.getRole() === 'ROLE_ADMIN')
            this.foodService.isAdmin = true;
          this.router.navigate(['search-bar']);
          this.loggedIn = true;
          this.foodService.isLoggedIn = true;
          this.name = this.userService.getUser(user.username).lastname.concat(".").concat(this.userService.getUser(user.username).firstname);
          this.username=user.username;

     
      },(error: HttpErrorResponse) => {
        this.validCredentials = false;
       // alert("error" + error.message);
        this.router.navigate(['login']);
      }
       );
    
   }

  logout() {
    this.loggedInUser = {loggedOut:true};
    this.foodService.isAdmin = false;
    this.loggedIn = false;
    this.foodService.isLoggedIn = false;
    this.foodService.clickedOnAdd = false;
    this.foodService.addedToCart = false;
    localStorage.removeItem('token')
    //alert("venu askedddddd------"+localStorage.getItem('token'))
    this.router.navigate(['login']);
    // this.router.navigate(['search-bar']);
  }

  public setToken(token: string) {
    this.token = token;
  }
  public getToken() {
    return this.token;
  }
  public setRole(role: string) {
    this.role = role;
  }
  public getRole() {
    return this.role;
  }
}

