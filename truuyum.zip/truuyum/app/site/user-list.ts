export interface UserList {
  userName: string;
  firstName: string;
  lastName: string;
  password: string;
  confirmPassword: string;
}
