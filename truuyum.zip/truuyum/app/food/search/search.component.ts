import { Component, OnInit, Input } from '@angular/core';
import { item } from '../item-info/item';
import { FoodServiceService } from '../food-service.service';
import { MenuItemService } from 'src/app/service/menu-item.service';
import { Router } from '@angular/router';
import { AuthServiceService } from 'src/app/site/auth-service.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  items:item[];
  searchKey:string;
  itemList:item[];
  filteredItemList:any;
  isAdmin:boolean;
  isCArt:boolean;
  constructor(private foodService:FoodServiceService,private _menuService:MenuItemService,private route:Router, private authService: AuthServiceService) { 
    //localStorage.removeItem('token')
  }

  ngOnInit() {
   // this.route.navigate(['search-bar'])
    this.isAdmin = this.foodService.isAdmin;
    this.isCArt=this.authService.loggedIn
    
    if(!this.isAdmin && !this.isCArt) {
      localStorage.removeItem('token')
    }

    this._menuService.getAllMenuItems().subscribe(
      (data)=>{
      this.itemList=data,
      this.filteredItemList = data;
      });
    
  }

  search() {
    this.filteredItemList = this.itemList.filter(item => item.name.toLocaleLowerCase().includes(this.searchKey.toLocaleLowerCase()));
    this._menuService.getSubject().next(this.filteredItemList);
  }
}
