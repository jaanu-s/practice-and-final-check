import { Injectable, Output, EventEmitter } from '@angular/core';
import { item } from './item-info/item';
import { Subject, Observable } from 'rxjs';
import { Router } from '@angular/router';
import { MenuItemService } from '../service/menu-item.service';

@Injectable({
  providedIn: 'root'
})
export class FoodServiceService {

  private subject = new Subject<item[]>();
  isAdmin:boolean = false;
  addedToCart:boolean = false;
  cartAddedId:number;
  isLoggedIn:boolean = false;
  clickedOnAdd:boolean = false;
  items:any;
  // items:item[] = [
  //   {id:1,name:"Sandwich",price:99.00,active:false,dateOfLaunch:new Date("12/11/2015"),category:"Starter",freeDelivery:false,
  //   image:'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1353&q=80'},
  //   {id:2,name:"Burger",price:129.00,active:true,dateOfLaunch:new Date("12/01/2015"),category:"Main Course",freeDelivery:true,
  //   image:'https://images.unsplash.com/photo-1512152272829-e3139592d56f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80'},
  //   {id:3,name:"Pizza",price:219.00,active:true,dateOfLaunch:new Date("07/25/2015"),category:"Main Course",freeDelivery:false,
  //   image:'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1355&q=80'},
  //   {id:4,name:"French Fries",price:69.00,active:true,dateOfLaunch:new Date("09/12/2015"),category:"Starter",freeDelivery:true,
  //   image:'https://images.unsplash.com/photo-1526230427044-d092040d48dc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80'},
  //   {id:5,name:"Chocholate Brownie",price:46.00,active:true,dateOfLaunch:new Date("12/11/2025"),category:"Dessert",freeDelivery:false,
  //   image:'https://images.unsplash.com/photo-1564355808539-22fda35bed7e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1330&q=80'}
  // ]

  constructor(private router:Router,private _menuService:MenuItemService) { }
  foodItem:item;
  getFoodItems(): item[] {
    
    this._menuService.getAllMenuItems().subscribe((item)=>this.items=item)
    return this.items;
  }
  getAllFoodItems():item[] {
    this._menuService.getAllMenuItems().subscribe((item)=>this.items=item)
    return this.items;
  }
  getSubject(): Subject<item[]> {
    return this.subject;
  }
  addToCart(username:string,foodItemId:number) {
    if(this.isLoggedIn){
          this._menuService.addCartItem(username,foodItemId).subscribe((res)=>{alert("item added")});
          this.addedToCart = true;
          this.cartAddedId = foodItemId;
          
        }
    else{
          this.addedToCart = true;
          this.cartAddedId = foodItemId;
      this.router.navigate(['login'])
  }
  }
  updateFoodItem(foodItem:item){
    for(let i = 0; i<this.items.length;i++){
      if(this.items[i].id == foodItem.id){
        this.items[i] = foodItem;
        break;
      }
    }
  }
  getFoodItem(foodItemId:number):item {
    this._menuService.getMenuItem(foodItemId).subscribe((item)=>this.foodItem=item)
      return this.foodItem;
    }
  }

