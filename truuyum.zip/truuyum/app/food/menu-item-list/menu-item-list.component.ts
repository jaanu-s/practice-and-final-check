import { Component, OnInit } from '@angular/core';
import { MenuItemService } from 'src/app/service/menu-item.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-menu-item-list',
  templateUrl: './menu-item-list.component.html',
  styleUrls: ['./menu-item-list.component.css']
})
export class MenuItemListComponent implements OnInit {
  items:any;
  constructor(private _menuService:MenuItemService) { }

  ngOnInit() {
   // alert("hai menu")
    this._menuService.getAllMenuItems().subscribe(
      (item)=>{
       // alert("hjhhkjh"+JSON.stringify(item))
        this.items=item},
      (error: HttpErrorResponse) => {
        this.items = error;

        //alert("errrr"+this.items.message+"hhhhh"+error)
        if (error instanceof Error) {
         alert("client side error" + error.message);
        } else {
         alert("server side error" + error.message);
        }
      }
     
    ); 
  }

}
