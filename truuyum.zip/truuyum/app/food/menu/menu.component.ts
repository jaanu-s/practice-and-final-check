import { Component, OnInit, Input, EventEmitter } from '@angular/core';

import { FoodServiceService } from '../food-service.service';
import { CartServiceService } from 'src/app/shopping/cart-service.service';
import { MenuItemService } from 'src/app/service/menu-item.service';
import { Router } from '@angular/router';
import { AuthServiceService } from 'src/app/site/auth-service.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

   //items:item[];
   isAdmin:boolean;
   items:any;
   username:string;
  constructor(private route:Router,private foodService:FoodServiceService, private cartService:CartServiceService,private _menuService:MenuItemService,private authService:AuthServiceService) { 
 
  }

  ngOnInit() {
    this.isAdmin = this.foodService.isAdmin;

    this.username=this.authService.username;
    alert(this.username);
  
    if(this.isAdmin){
      this._menuService.getAllMenuItems().subscribe((data)=>this.items=data);
      
     // this.items = this.foodService.getAllFoodItems();
      this._menuService.getSubject().subscribe( (data)=>this.items=data);
     // this.foodService.getSubject().subscribe((data) => {
       // this.items = data;
      //});
    }
    else{
      this._menuService.getAllMenuItems().subscribe((data)=>this.items=data);
      this._menuService.getSubject().subscribe( (data)=>this.items=data);
     // this.items = this.foodService.getFoodItems();
     // this.foodService.getSubject().subscribe((data) => {
      //  this.items = data;
      //});
    }




// this._menuService.getAllMenuItems().subscribe((data)=>this.items=data);
// this._menuService.getSubject().subscribe( (data)=>this.items=data);
}


}
