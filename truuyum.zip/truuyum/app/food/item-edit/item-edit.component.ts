import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { item } from '../item-info/item';
import { FoodServiceService } from '../food-service.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { MenuItemService } from 'src/app/service/menu-item.service';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-item-edit',
  templateUrl: './item-edit.component.html',
  styleUrls: ['./item-edit.component.css']
})
export class ItemEditComponent implements OnInit {
  editForm: FormGroup;
  itemUpdated = false;
  

  id:number;
    name:string;
    price:number;
    active:boolean;
    dateOfLaunch:Date;
    category:string;
    freeDelivery:boolean;
    imageLink:string;

  constructor(private _date:DatePipe,private productsService: MenuItemService, private route: ActivatedRoute, private router: Router) { }
  product:item[];
  ngOnInit() {

    this.editForm = new FormGroup({
      'name': new FormControl(null, [Validators.required, Validators.maxLength(200)]),
      'imageLink': new FormControl(null, [Validators.required]),
      'price': new FormControl(null, [Validators.required, Validators.pattern('^[0-9]+$')]),
      'category': new FormControl(null, Validators.required),
      'dateOfLaunch': new FormControl(null),
      'active': new FormControl(null, Validators.required),
      'freeDelivery': new FormControl(null)
    });
    this.route.params.subscribe((params: Params) => {
      this.id = params['id'];

     // console.log("my  id"+this.id);
      
      this.productsService.getMenuItem(this.id).subscribe((product: item) => {
      //alert("-------------------------"+this.product)
       var d =this._date.transform(product.dateOfLaunch,'yyyy-MM-dd')
        //d.toLocaleDateString()
       // console.log(d.toLocaleDateString());

        if (product) {
          this.editForm.patchValue({
            name: product.name,
            imageLink: product.image,
            price: product.price,
            category: product.category,
            dateOfLaunch: d,
            active: product.active,
            freeDelivery: product.freeDelivery
          });
        } else {
          this.router.navigate(['not-found']);
        }
      });
    });
  }

  onSubmitEditForm() {
    var items=this.editForm.value;
   // console.log(items.active);

    alert("my  id"+this.id);

    var newData={"id":this.id,"name":items.name,"price":items.price,"active":items.active,"dateOfLaunch":items.dateOfLaunch,
    "category":items.category,"freeDelivery":items.freeDelivery,"image":items.imageLink}

  this.productsService.save(newData).subscribe();
  //this.productsService.getAllMenuItems().subscribe((items)=>this.product=items)

    this.itemUpdated = true;

  }

  

}



