export interface FoodItem {

  Id:number;
  Name:string;
  Active:boolean;
  FreeDelivery:boolean;
  Category:string;
  DateOfLaunch:Date;
  Price:number;

}
