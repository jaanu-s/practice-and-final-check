import { item } from "../food/item-info/item";

export interface cart {
    foodItemList:item[];
    total:number;
}