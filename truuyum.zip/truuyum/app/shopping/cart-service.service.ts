import { Injectable, Output, EventEmitter } from '@angular/core';
import { cart } from './cart';
import { AuthServiceService } from '../site/auth-service.service';

import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CartServiceService {

  @Output() cartUpdated = new EventEmitter();

  cartItems:cart =  {foodItemList:[],total:0};
  username:string;
  baseurl:string=environment.baseUrl;
  cartUrl:string=environment.cartSUrl;
  constructor(private authService:AuthServiceService,private _httpClient:HttpClient) {
    this.username=this.authService.username
   }

  getCart():cart {
    return this.cartItems;
  }
  calculateTotal() {
    this.cartItems.total = 0;
    for(let i=0;i<this.cartItems.foodItemList.length;i++){
        this.cartItems.total += this.cartItems.foodItemList[i].price;
    }
    this.cartUpdated.emit;
  }

  getAllCartItems(userId:string):Observable<any> {
    var headers_object = new HttpHeaders();
    headers_object.set('Content-Type', 'application/json');
    var head=headers_object.set("Authorization", "Bearer " + localStorage.getItem('token'));
    alert(JSON.stringify(headers_object)+"header object"+localStorage.getItem('token'));
    return this._httpClient.get<any>(this.cartUrl+userId,{headers:head});
    //return this._httpClient.get<any>("http://localhost:8083/carts/"+userId);
  }
  deleteCartItem(userId,menuItemId):Observable<any> {
    var headers_object = new HttpHeaders();
    headers_object.set('Content-Type', 'application/json');
    var head=headers_object.set("Authorization", "Bearer " + localStorage.getItem('token'));
    alert(JSON.stringify(headers_object)+"header object"+localStorage.getItem('token'));
    return this._httpClient.delete<any>(this.cartUrl+userId+"/"+menuItemId,{headers:head});
    //return this._httpClient.delete<any>("http://localhost:8083/carts/"+userId+"/"+menuItemId);
  }
}
