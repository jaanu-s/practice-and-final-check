import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { cart } from '../cart';
import { CartServiceService } from '../cart-service.service';
import { FoodServiceService } from 'src/app/food/food-service.service';
import { AuthServiceService } from 'src/app/site/auth-service.service';
import { Observable } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  @Output() addToCartClicked = new EventEmitter();
  cart: cart;
  username: string;
  total = 0;
  message1: string;
  finalData:string;
  constructor(private cartService: CartServiceService, private authService: AuthServiceService) { }

  ngOnInit() {
  
    
   
    this.username = this.authService.username;
    //  this.cartService.calculateTotal();
    this.cartService.getAllCartItems(this.username).subscribe((data) => {
      this.cart = data,
      this.total = this.cart.total;
    }, (error: HttpErrorResponse) => {
      ;
      if (error instanceof Error) {
        alert("client side error" + error.message);
      } else {
        alert("server side error" + (error.error.message));

        this.total = 0;
        this.message1 = error.error.message;
         }
    });
    //this.cartService.calculateTotal();
    //  this.cart = this.cartService.getCart();
  }

  onDeleteClick(id) {
    //alert("came through button")
    this.cartService.deleteCartItem(this.username, id).subscribe((res) => alert("in cart delete"));
    this.ngOnInit(); 
  }

}
